package com.example.giphy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GiphyApplicationTests {

	@Test
	void contextLoads() {
	}

}
