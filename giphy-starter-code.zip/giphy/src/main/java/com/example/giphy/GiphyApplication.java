package com.example.giphy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GiphyApplication {

	public static void main(String[] args) {
		SpringApplication.run(GiphyApplication.class, args);
	}

}
